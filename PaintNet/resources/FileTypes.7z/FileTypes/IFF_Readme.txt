IFF File Type for Paint.NET ==================
=========================== by Brian Handscomb


This is a quick and dirty implementation of a loader for
IFF ILBM images (native file format of the old Commodore
Amiga computers)

This undoubtedly has bugs and will likely not load every
images even taking into account the known limitations, like
for example not supporting images with more than 8 bits per
pixel, e.g. so called IFF24.

Amiga images do not always use "square" pixels, and there
is some support for preserving the original aspect ratio
by doubling up pixels. For example a lo-res interlaced
picture 320x400 will be loaded at 640x400. A hi-res non-
interlaced picture 640x200 will also be loaded at 640x400.

It does support HAM6 and HAM8 modes (and in theory the
VERY rare HAM5 and HAM7 modes) often used for raytraced
images or where "true colour" images have been converted
for display on an Amiga.



Version History
===============

1.0 - September 2010
Initial version, tested on Paint.NET 3.5.5

1.1 - April 2013
Slight tweak, now works with Paint.NET 3.5.10
(no functional changes)



About the Example Images
========================

Athena, BluePorsche, MazdaRx7, SachsCastle and Shuttle
are "plain" images from an early "Fish Disk" (number 30).

Glass is a HAM6 raytraced image from another early "Fish
Disk" (number 44)

Finally, MightyMo_1 was sourced from Aminet's pix/trace
section, along with a description from the creator. The
image itself is unchanged though the filename has been
slightly changed to suit PC/Windows naming conventions.
This shows what the HAM8 display mode could do.


B-)
