﻿// Author of OraFormat.cs: 2010 Maia Kozheva <sikon@ubuntu.com>
//
// Copyright (c) 2010 Maia Kozheva <sikon@ubuntu.com>
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

using System;
using System.IO;
using System.Drawing;
using System.Xml;
using PaintDotNet;
using PaintDotNet.Data;
using ICSharpCode.SharpZipLib.Zip;
using System.Drawing.Imaging;
using System.Globalization;

namespace OpenRaster_Filetype
	{
	public class OraFileType : FileType
		{
		private const int ThumbMaxSize = 256;

		public OraFileType()
			: base("OpenRaster", FileTypeFlags.SupportsLoading | FileTypeFlags.SupportsSaving | FileTypeFlags.SupportsLayers, new String[] { ".ora" })
			{
			strokeMapVersions = new string[2] { "mypaint_strokemap", "mypaint_strokemap_v2" };
			}

		/// <summary>
		/// Gets the bitmap from the ora layer.
		/// </summary>
		/// <param name="xofs">The x offset of the layer image.</param>
		/// <param name="yofs">The y offset of the layer image.</param>
		/// <param name="inStream">The input stream containing the layer image.</param>
		/// <param name="baseWidth">The width of the base document.</param>
		/// <param name="baseHeight">The height of the base document.</param>
		private unsafe Bitmap GetBitmapFromOraLayer(int xofs, int yofs, Stream inStream, int baseWidth, int baseHeight)
			{
			Bitmap image = null;

			using (Bitmap layer = new Bitmap(baseWidth, baseHeight))
				{
				using (Bitmap bmp = new Bitmap(inStream))
					{
					BitmapData layerData = layer.LockBits(new Rectangle(xofs, yofs, bmp.Width, bmp.Height), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
					BitmapData bmpData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadOnly, bmp.PixelFormat);

					int bpp = Bitmap.GetPixelFormatSize(bmp.PixelFormat) / 8;

					for (int y = 0; y < bmp.Height; y++)
						{
						for (int x = 0; x < bmp.Width; x++)
							{
							byte* dst = (byte*)layerData.Scan0.ToPointer() + (y * layerData.Stride) + (x * 4);
							byte* src = (byte*)bmpData.Scan0.ToPointer() + (y * bmpData.Stride) + (x * bpp);
							
							dst[0] = src[0]; // B
							dst[1] = src[1]; // G
							dst[2] = src[2]; // R

							if (bpp == 4)
								{
								dst[3] = src[3]; // A
								}
							else
								{
								dst[3] = 255;
								}
							}
						}
					bmp.UnlockBits(bmpData);
					layer.UnlockBits(layerData);
					}
				image = (Bitmap)layer.Clone();
				}
			return image;
			}

		/// <summary>
		/// The formats for MyPaint's stroke map, version 1 and version 2.
		/// </summary>
		private readonly string[] strokeMapVersions;

		protected override Document OnLoad(Stream input)
			{
			using (ZipFile file = new ZipFile(input))
				{
				XmlDocument stackXml = new XmlDocument();
				stackXml.Load(file.GetInputStream(file.GetEntry("stack.xml")));

				XmlElement imageElement = stackXml.DocumentElement;
				int width = int.Parse(imageElement.GetAttribute("w"), CultureInfo.InvariantCulture);
				int height = int.Parse(imageElement.GetAttribute("h"), CultureInfo.InvariantCulture);

				Document doc = new Document(width, height);

				XmlElement stackElement = (XmlElement)stackXml.GetElementsByTagName("stack")[0];
				XmlNodeList layerElements = stackElement.GetElementsByTagName("layer");

				if (layerElements.Count == 0)
					throw new FormatException("No layers found in OpenRaster file");
				int layerCount = layerElements.Count - 1;

				for (int i = layerCount; i >= 0; i--) // The last layer in the list is the background so load in reverse
					{
					XmlElement layerElement = (XmlElement)layerElements[i];
					int x = int.Parse(GetAttribute(layerElement, "x", "0"), CultureInfo.InvariantCulture); // the x offset within the layer
					int y = int.Parse(GetAttribute(layerElement, "y", "0"), CultureInfo.InvariantCulture); // the y offset within the layer

					int layerNum = layerCount - i;

					string name = GetAttribute(layerElement, "name", string.Format("Layer {0}", layerNum));

					ZipEntry zf = file.GetEntry(layerElement.GetAttribute("src"));

					using (Stream s = file.GetInputStream(zf))
						{
						using (Bitmap bmp = GetBitmapFromOraLayer(x, y, s, width, height))
							{
							BitmapLayer myLayer = null;
							if (i == layerCount) // load the background layer first
								{
								myLayer = Layer.CreateBackgroundLayer(width, height);
								}
							else
								{
								myLayer = new BitmapLayer(width, height);
								}

							myLayer.Name = name;
							myLayer.Opacity = ((byte)(255.0 * double.Parse(GetAttribute(layerElement, "opacity", "1"), CultureInfo.InvariantCulture)));
							myLayer.Visible = (GetAttribute(layerElement, "visibility", "visible") == "visible"); // newer ora files have this
							myLayer.SetBlendOp(GetBlendOp(GetAttribute(layerElement, "composite-op", "src-over")));

							myLayer.Surface.CopyFromGdipBitmap(bmp, false); // does this make sense?

							string backTile = GetAttribute(layerElement, "background_tile", string.Empty);
							if (!string.IsNullOrEmpty(backTile))
								{
								ZipEntry tileZf = file.GetEntry(backTile);
								byte[] tileBytes = null;
								using (Stream tileStream = file.GetInputStream(tileZf))
									{
									tileBytes = new byte[(int)tileStream.Length];

									int numBytesToRead = (int)tileStream.Length;
									int numBytesRead = 0;
									while (numBytesToRead > 0)
										{
										// Read may return anything from 0 to numBytesToRead.
										int n = tileStream.Read(tileBytes, numBytesRead, numBytesToRead);
										// The end of the file is reached.
										if (n == 0)
											{
											break;
											}
										numBytesRead += n;
										numBytesToRead -= n;
										}
									}

								string tileData = Convert.ToBase64String(tileBytes);
								// convert the tile image to a Base64String and then save it in the layer's MetaData.
								myLayer.Metadata.SetUserValue("OraBackgroundTile", tileData);
								}

							foreach (string version in strokeMapVersions)
								{
								string strokeMap = GetAttribute(layerElement, version, string.Empty);
								if (!string.IsNullOrEmpty(strokeMap))
									{
									ZipEntry strokeZf = file.GetEntry(strokeMap);
									byte[] strokeBytes = null;
									using (Stream strokeStream = file.GetInputStream(strokeZf))
										{
										strokeBytes = new byte[(int)strokeStream.Length];

										int numBytesToRead = (int)strokeStream.Length;
										int numBytesRead = 0;
										while (numBytesToRead > 0)
											{
											// Read may return anything from 0 to numBytesToRead.
											int n = strokeStream.Read(strokeBytes, numBytesRead, numBytesToRead);
											// The end of the file is reached.
											if (n == 0)
												{
												break;
												}
											numBytesRead += n;
											numBytesToRead -= n;
											}
										}
									string strokeData = Convert.ToBase64String(strokeBytes);
									// convert the stroke map to a Base64String and then save it in the layer's MetaData.

									myLayer.Metadata.SetUserValue("OraMyPaintStrokeMapData", strokeData);

									// Save the version of the stroke map in the MetaData
									myLayer.Metadata.SetUserValue("OraMyPaintStrokeMapVersion", version);
									}
								}
							doc.Layers.Insert(layerNum, myLayer);
							}
						}
					}
				return doc;
				}
			}

		// A struct to store the new x,y offsets
		private struct LayerInfo
			{
			public int x;
			public int y;

			public LayerInfo(int x, int y)
				{
				this.x = x;
				this.y = y;
				}
			}

		protected override void OnSave(Document input, Stream output, SaveConfigToken token, Surface scratchSurface, ProgressEventHandler callback)
			{
			using (ZipOutputStream stream = new ZipOutputStream(output))
				{
				stream.IsStreamOwner = false;
				stream.UseZip64 = UseZip64.Off;
				ZipEntry mimetype = new ZipEntry("mimetype");
				mimetype.CompressionMethod = CompressionMethod.Stored;
				stream.PutNextEntry(mimetype);

				byte[] databytes = System.Text.Encoding.ASCII.GetBytes("image/openraster");
				stream.Write(databytes, 0, databytes.Length);

				LayerInfo[] layerInfo = new LayerInfo[input.Layers.Count];
				for (int i = 0; i < input.Layers.Count; i++)
					{
					BitmapLayer layer = (BitmapLayer)input.Layers[i];
					Rectangle bounds = layer.Surface.Bounds;

					int left = layer.Width;
					int top = layer.Height;
					int right = 0;
					int bottom = 0;
					unsafe
						{
						for (int y = 0; y < layer.Height; y++)
							{
							ColorBgra* row = layer.Surface.GetRowAddress(y);
							ColorBgra* pixel = row;

							for (int x = 0; x < layer.Width; x++)
								{
								if (pixel->A > 0)
									{
									if (x < left)
										{
										left = x;
										}
									if (x > right)
										{
										right = x;
										}
									if (y < top)
										{
										top = y;
										}
									if (y > bottom)
										{
										bottom = y;
										}
									}
								pixel++;
								}
							}
						}

					if (left < layer.Width && top < layer.Height) // is the layer not empty
						{
						bounds = new Rectangle(left, top, (right - left)+1, (bottom - top)+1); // clip it to the visible rectangle
						layerInfo[i] = new LayerInfo(left, top); 
						}
					else
						{
						layerInfo[i] = new LayerInfo(0, 0);
						}
					
					string tileData = layer.Metadata.GetUserValue("OraBackgroundTile");
					if (!string.IsNullOrEmpty(tileData)) // save the background_tile png if it exists
						{
						byte[] tileBytes = Convert.FromBase64String(tileData);
						stream.PutNextEntry(new ZipEntry("data/background_tile.png"));
						stream.Write(tileBytes, 0, tileBytes.Length);
						}

					string strokeData = layer.Metadata.GetUserValue("OraMyPaintStrokeMapData");
					if (!string.IsNullOrEmpty(strokeData)) // save MyPaint's stroke data if it exists
						{
						byte[] tileBytes = Convert.FromBase64String(strokeData);
						stream.PutNextEntry(new ZipEntry("data/layer" + i.ToString(CultureInfo.InvariantCulture) + "_strokemap.dat"));
						stream.Write(tileBytes, 0, tileBytes.Length);
						}

					byte[] buf = null;
					using (MemoryStream ms = new MemoryStream())
						{
						layer.Surface.CreateAliasedBitmap(bounds, true).Save(ms, ImageFormat.Png);
						buf = ms.ToArray();
						}
					stream.PutNextEntry(new ZipEntry("data/layer" + i.ToString(CultureInfo.InvariantCulture) + ".png"));
					stream.Write(buf, 0, buf.Length);
					}

				stream.PutNextEntry(new ZipEntry("stack.xml"));
				databytes = GetLayerXmlData(input.Layers, layerInfo);
				stream.Write(databytes, 0, databytes.Length);

				using (Surface flat = new Surface(input.Width, input.Height))
					{
					input.Flatten(flat);
					Size thumbSize = GetThumbDimensions(input.Width, input.Height);

					Surface scale = new Surface(thumbSize);
					scale.FitSurface(ResamplingAlgorithm.SuperSampling, flat);

					using (MemoryStream ms = new MemoryStream())
						{
						scale.CreateAliasedBitmap().Save(ms, ImageFormat.Png);
						databytes = ms.ToArray();
						}
					scale.Dispose();
					}
				stream.PutNextEntry(new ZipEntry("Thumbnails/thumbnail.png"));
				stream.Write(databytes, 0, databytes.Length);
				}
			System.Diagnostics.Debug.WriteLine("All done here");
			}

		private byte[] GetLayerXmlData(LayerList layers, LayerInfo[] info) // OraFormat.cs - minor changes, no idea if still works
			{
			byte[] buf = null;

			using (MemoryStream ms = new MemoryStream())
				{
				XmlTextWriter writer = new XmlTextWriter(ms, System.Text.Encoding.UTF8);
				writer.Formatting = Formatting.Indented;
				writer.WriteStartDocument();

				writer.WriteStartElement("image");
				writer.WriteAttributeString("w", layers.GetAt(0).Width.ToString(CultureInfo.InvariantCulture));
				writer.WriteAttributeString("h", layers.GetAt(0).Height.ToString(CultureInfo.InvariantCulture));

				writer.WriteStartElement("stack");
				writer.WriteAttributeString("opacity", "1");
				writer.WriteAttributeString("name", "root");

				// ORA stores layers top to bottom
				for (int i = layers.Count - 1; i >= 0; i--)
					{
					BitmapLayer layer = (BitmapLayer)layers[i];

					writer.WriteStartElement("layer");

					string backTile = layer.Metadata.GetUserValue("OraBackgroundTile");
					if (!string.IsNullOrEmpty(backTile))
						{
						writer.WriteAttributeString("background_tile", "data/background_tile.png");
						}
					string strokeMapVersion = layer.Metadata.GetUserValue("OraMyPaintStrokeMapVersion");
					if (!string.IsNullOrEmpty(strokeMapVersion))
						{
						writer.WriteAttributeString(strokeMapVersion, "data/layer" + i.ToString(CultureInfo.InvariantCulture) + "_strokemap.dat");
						}

					writer.WriteAttributeString("opacity", ((double)(layer.Opacity / 255.0)).Clamp(0.0, 1.0).ToString("N2", CultureInfo.InvariantCulture)); // this is even more bizarre :D
					if (string.IsNullOrEmpty(strokeMapVersion)) // the stroke map layer does not have a name
						{
						writer.WriteAttributeString("name", layer.Name);
						}
					writer.WriteAttributeString("src", "data/layer" + i.ToString(CultureInfo.InvariantCulture) + ".png");
					writer.WriteAttributeString("visible", layer.Visible ? "visible" : "hidden");

					writer.WriteAttributeString("x", info[i].x.ToString(CultureInfo.InvariantCulture));
					writer.WriteAttributeString("y", info[i].y.ToString(CultureInfo.InvariantCulture));
					writer.WriteAttributeString("composite-op", GetSVGBlend(layer.BlendOp));

					writer.WriteEndElement();
					}
				writer.WriteEndElement(); // stack
				writer.WriteEndElement(); // image
				writer.WriteEndDocument();

				writer.Close();

				buf = ms.ToArray();
				}
			return buf;
			}

		private Size GetThumbDimensions(int width, int height) // OraFormat.cs
			{
			if (width <= ThumbMaxSize && height <= ThumbMaxSize)
				return new Size(width, height);

			if (width > height)
				return new Size(ThumbMaxSize, (int)((double)height / width * ThumbMaxSize));
			else
				return new Size((int)((double)width / height * ThumbMaxSize), ThumbMaxSize);
			}

		private static string GetAttribute(XmlElement element, string attribute, string defValue) // OraFormat.cs
			{
			string ret = element.GetAttribute(attribute);
			return string.IsNullOrEmpty(ret) ? defValue : ret;
			}

		private static string GetSVGBlend(UserBlendOp pdnblend)
			{
			string blendOpSrt = "src-over";
			string result = pdnblend.GetType().Name.ToLower().Remove(pdnblend.GetType().Name.Length - 7, 7);

			switch (result)
				{
				case "normal": blendOpSrt = "src-over"; break;
				case "multiply": blendOpSrt = "multiply"; break;
				case "additive": blendOpSrt = "plus"; break;
				case "colorburn": blendOpSrt = "color-burn"; break;
				case "colordodge": blendOpSrt = "color-dodge"; break;
				case "reflect": /* blendOpSrt = ""; */ break;
				case "glow": /* blendOpSrt = ""; */ break;
				case "overlay": blendOpSrt = "overlay"; break;
				case "difference": blendOpSrt = "difference"; break;
				case "negation": /* blendOpSrt = ""; */ break;
				case "lighten": blendOpSrt = "lighten"; break;
				case "darken": blendOpSrt = "darken"; break;
				case "screen": blendOpSrt = "screen"; break;
				case "xor": blendOpSrt = "xor"; break;
				default: blendOpSrt = "src-over"; break;
				}
			return blendOpSrt;
			}

		private UserBlendOp GetBlendOp(string svgblend)
			{
			UserBlendOp blendOp = UserBlendOps.CreateDefaultBlendOp();

			switch (svgblend.ToLower())
				{
				case "src-over": blendOp = UserBlendOps.CreateBlendOp(typeof(UserBlendOps.NormalBlendOp)); break;
				case "multiply": blendOp = UserBlendOps.CreateBlendOp(typeof(UserBlendOps.MultiplyBlendOp)); break;
				case "plus": blendOp = UserBlendOps.CreateBlendOp(typeof(UserBlendOps.AdditiveBlendOp)); break;
				case "color-burn": blendOp = UserBlendOps.CreateBlendOp(typeof(UserBlendOps.ColorBurnBlendOp)); break;
				case "color-dodge": blendOp = UserBlendOps.CreateBlendOp(typeof(UserBlendOps.ColorDodgeBlendOp)); break;
				case "reflect": blendOp = UserBlendOps.CreateBlendOp(typeof(UserBlendOps.ReflectBlendOp)); break;
				case "glow": blendOp = UserBlendOps.CreateBlendOp(typeof(UserBlendOps.GlowBlendOp)); break;
				case "overlay": blendOp = UserBlendOps.CreateBlendOp(typeof(UserBlendOps.OverlayBlendOp)); break;
				case "difference": blendOp = UserBlendOps.CreateBlendOp(typeof(UserBlendOps.DifferenceBlendOp)); break;
				case "negation": blendOp = UserBlendOps.CreateBlendOp(typeof(UserBlendOps.NegationBlendOp)); break;
				case "lighten": blendOp = UserBlendOps.CreateBlendOp(typeof(UserBlendOps.LightenBlendOp)); break;
				case "darken": blendOp = UserBlendOps.CreateBlendOp(typeof(UserBlendOps.DarkenBlendOp)); break;
				case "screen": blendOp = UserBlendOps.CreateBlendOp(typeof(UserBlendOps.ScreenBlendOp)); break;
				case "xor": blendOp = UserBlendOps.CreateBlendOp(typeof(UserBlendOps.XorBlendOp)); break;
				default: blendOp = UserBlendOps.CreateDefaultBlendOp(); break;
				}
			return blendOp;
			}
		}

	public class MyFileTypeFactory : IFileTypeFactory
		{
		public FileType[] GetFileTypeInstances()
			{
			return new FileType[] { new OraFileType() };
			}
		}
	}
